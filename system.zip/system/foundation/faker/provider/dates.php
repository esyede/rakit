<?php

namespace System\Foundation\Faker\Provider;

defined('DS') or exit('No direct script access.');

class Dates extends Base
{
    protected static $century = [
        'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X',
        'XI', 'XII', 'XIII', 'XIV', 'XV', 'XVI', 'XVII', 'XVIII', 'XIX',
        'XX', 'XXI',
    ];

    protected static function getMaxTimestamp($max = 'now')
    {
        if (is_numeric($max)) {
            return (int) $max;
        }

        return ($max instanceof \DateTime) ? $max->getTimestamp() : strtotime(empty($max) ? 'now' : $max);
    }

    public static function unixTime($max = 'now')
    {
        return mt_rand(0, static::getMaxTimestamp($max));
    }

    public static function dateTime($max = 'now')
    {
        return new \DateTime('@'.static::unixTime($max));
    }

    public static function dateTimeAD($max = 'now')
    {
        return new \DateTime('@'.mt_rand(-62135597361, static::getMaxTimestamp($max)));
    }

    public static function iso8601($max = 'now')
    {
        return static::date(\DateTime::ISO8601, $max);
    }

    public static function date($format = 'Y-m-d', $max = 'now')
    {
        return static::dateTime($max)->format($format);
    }

    public static function time($format = 'H:i:s', $max = 'now')
    {
        return static::dateTime($max)->format($format);
    }

    public static function dateTimeBetween($startDate = '-30 years', $endDate = 'now')
    {
        $start = ($startDate instanceof \DateTime) ? $startDate->getTimestamp() : strtotime($startDate);
        $end = static::getMaxTimestamp($endDate);

        if ($start > $end) {
            throw new \InvalidArgumentException('Start date must be anterior to end date.');
        }

        $timestamp = mt_rand($start, $end);
        $timestamp = new \DateTime('@'.$timestamp);
        $timestamp->setTimezone(new \DateTimeZone(date_default_timezone_get()));

        return $timestamp;
    }

    public static function dateTimeThisCentury($max = 'now')
    {
        return static::dateTimeBetween('-100 year', $max);
    }

    public static function dateTimeThisDecade($max = 'now')
    {
        return static::dateTimeBetween('-10 year', $max);
    }

    public static function dateTimeThisYear($max = 'now')
    {
        return static::dateTimeBetween('-1 year', $max);
    }

    public static function dateTimeThisMonth($max = 'now')
    {
        return static::dateTimeBetween('-1 month', $max);
    }

    public static function amPm($max = 'now')
    {
        return static::dateTime($max)->format('a');
    }

    public static function dayOfMonth($max = 'now')
    {
        return static::dateTime($max)->format('d');
    }

    public static function dayOfWeek($max = 'now')
    {
        return static::dateTime($max)->format('l');
    }

    public static function month($max = 'now')
    {
        return static::dateTime($max)->format('m');
    }

    public static function monthName($max = 'now')
    {
        return static::dateTime($max)->format('F');
    }

    public static function year($max = 'now')
    {
        return static::dateTime($max)->format('Y');
    }

    public static function century()
    {
        return static::randomElement(static::$century);
    }

    public static function timezone()
    {
        return static::randomElement(\DateTimeZone::listIdentifiers());
    }
}
