#### Bahasa Indonesia

Library ini adaptasi dari [nette/tracy](https://github.com/nette/tracy) v2.5.9.
Tracy dirilis dibawah Lisensi New BSD atau GNU GPLv2/3. Lihat file LICENSE untuk lebih detail.



#### English

This library is adapted from [nette/tracy](https://github.com/nette/tracy) v2.5.9.
Tracy is released under the New BSD License or GNU GPLv2/3. See LICENSE file for details.
