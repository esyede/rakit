<?php
namespace System\Console\Commands;

defined('DS') or exit('No direct script access.');

abstract class Command
{
    // ..
}
